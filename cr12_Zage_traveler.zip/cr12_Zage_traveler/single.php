
<?php get_header(); ?>
   
   <div class="container mt-5 p-2">
    
   
          <?php if(have_posts()) : ?> <!--  If there are posts available  -->
   
          <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop
   -->
   <h1><?php the_title(); ?></h1>
   <p class="card-text"><small class="text-muted">Author: <?php the_author(); ?> | Date: <?php the_time('F j, Y g:i a'); ?></small></p>
   <?php if(has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail('medium'); ?>
                        <?php endif; ?>
   <div class="p-2">

   <?php the_content(); ?>

   </div>
   <div class="p-2">

<?php comments_template(); ?>

</div>


          <?php endwhile; ?><!--end the while loop-->
   
          <?php else :?> <!-- if no posts are found then: -->
          <p>No posts found</p>
          <?php endif; ?> <!-- end if -->

      </div>

    <?php get_footer(); ?>