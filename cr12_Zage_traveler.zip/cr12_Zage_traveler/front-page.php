<?php get_header();?>
<div class="jumbotron jumbotron-fluid m-0">
        <div class="container">
          <h1 class="display-4">Travel Blog</h1>
        </div>
      </div>

<div id="indexbody">
</div>
<div id="indexcontent">
-->
  
   <?php get_footer(); ?>
