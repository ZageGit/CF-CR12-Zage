<?php get_header();?>
<div id="indexcontent">
      <div class="jumbotron jumbotron-fluid">
        <div class="container">
          <h1 class="display-4">Travel Blog</h1>
        </div>
      </div>
   <div class="container d-flex">
     <div id="cardcontainer">

<?php if(have_posts()) : ?> 
<?php while(have_posts()) : the_post(); ?>

<div class="card mb-3 bg-light">
            <div class="row g-0">
              <div class="col-md-4">
                <?php if(has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail('medium'); ?>
                        <?php endif; ?>
              </div>
              <div class="col-md-8">
                <div class="card-body">
                  <h5 class="card-title"><?php the_title(); ?></h5>
                  <p class="card-text">
                  <?php the_excerpt(); ?>
                  </p>
                  <p class="card-text">
                      <p><?php the_date(); ?></p>
                      <p><?php the_author(); ?></p>
                    <a href="<?php the_permalink(); ?>"><button type="button" class="btn btn-primary">Read</button></a>
                  </p>
                </div>
              </div>
            </div>
          </div>

       <?php endwhile; ?><!--end the while loop-->

       <?php else :?> <!-- if no posts are found then: -->

       <p>No posts found</p>  <!-- no posts found displayed -->
       <?php endif; ?> <!-- end if -->
   </div>
   <?php get_footer(); ?>
