
  <?php wp_footer(); ?>

<!-- Footer -->
<footer class="page-footer sticky-bottom bg-light text-dark mt-2">
  <div class="footer-copyright text-center py-3">
     <p><small class="text-muted"><?php dynamic_sidebar('footer'); ?></small></p>
  </div>
 

</footer>
<!-- Footer -->



</body>
</html>