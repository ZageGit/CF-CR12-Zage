<?php get_header(); ?>
<?php if(have_posts()) : ?> <!--  If there are pages available  -->

<?php while(have_posts()) : the_post(); ?> 
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4"><?php the_title(); ?></h1>
    <p class="lead">This is a modified jumbotron that occupies the entire horizontal space of its parent.</p>
  </div>
  </div>
   <div class="container">
       
       <?php the_content();?><!--retrieves content-->

       <?php endwhile; ?><!--end the while loop-->

       <?php else :?> <!-- if no page is found then: -->

       <p>No page found</p>
       <?php endif; ?> <!-- end if -->
   </div>

  <?php get_footer(); ?>